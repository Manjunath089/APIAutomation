package pojo;

public class InstallmentScheduleSpecOutput {
	
	private String id;
	private String href;
	
	public String getId() {
		return id;
	}
	
	public String getHref() {
		return href;
	}
		

}
